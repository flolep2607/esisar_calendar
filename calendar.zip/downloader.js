const fs = require("fs");
const cache = require('memory-cache');
const fetch = require("node-fetch");
const icsparsesr = require("cal-parser");
const regex_location = /([ABCD][0-9]+)/im;
const regex_summary = /([A-Z]+[0-9]+)/im;
const regex_classe = /([1-5])A/im;
const regex_finder = /(?<year1>[1-5]A)M(?<matiere>[A-Z]+[0-9]+)_[0-9]{4}_S[0-9]+_(?<type1>CM|TD|TDM|TP|SOUTIEN|PROJET|TP-MINIGROUPE|HA)_G(?<groupe1>[1-9]) (?<teacher1>[^\(\*]*)|(?<year2>[1-5]APP)-(?<type2>CM|TD|TDM|TP|SOUTIEN|PROJET|TP-MINIGROUPE|HA)(?<groupe2>[1-9]+)(?<teacher2>[^\(\*]*)|(?<year3>[1-5]A)/i;
const base64token = Buffer.from(`${process.env.EDT_USER}:${process.env.EDT_PASSWORD}`).toString('base64');

const downloader = (code, res) => {
    let data_cached = cache.get(code);
    if (!data_cached) {
        fetch(`https://edt.grenoble-inp.fr/directCal/2021-2022/esisar/etudiant/jsp/custom/modules/plannings/direct_cal.jsp?resources=${code}`,
            {
                "headers": {
                    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                    "accept-language": "fr,fr-FR;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
                    "sec-ch-ua": "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"98\", \"Microsoft Edge\";v=\"98\"",
                    "sec-ch-ua-mobile": "?0",
                    "sec-ch-ua-platform": "\"Windows\"",
                    "sec-fetch-dest": "document",
                    "authorization": `Basic ${base64token}`, //user:password en base64
                    "sec-fetch-mode": "navigate",
                    "sec-fetch-site": "none",
                    "sec-fetch-user": "?1",
                    "upgrade-insecure-requests": "1"
                },
                "referrerPolicy": "strict-origin-when-cross-origin",
                "body": null,
                "method": "GET"
            })
            .then(r => r.text())
            .then(r => {
                const data = icsparsesr.parseString(r);
                const data_to_send=data.events.map(event => {
                    try {
                        let parsed = regex_finder.exec(event.description.value);
                        const year = parsed.groups.year1 || parsed.groups.year2 || parsed.groups.year3;
                        const teacher = parsed.groups.teacher1 || parsed.groups.teacher2;
                        const type = parsed.groups.type1 || parsed.groups.type2;
                        const groupe = parsed.groups.groupe1 || parsed.groups.groupe2;
                        return {
                            id: event.uid.value,
                            start: event.dtstart.value,
                            end: event.dtend.value,
                            summary: regex_summary.exec(event.summary.value) ? regex_summary.exec(event.summary.value)[0] : null,
                            location: regex_location.exec(event.location.value) ? regex_location.exec(event.location.value)[0] : null,
                            description: event.description.value,
                            classe: regex_classe.exec(event.description.value) ? regex_classe.exec(event.description.value)[0] : null,
                            year: year ? year.trim() : null,
                            teacher: teacher ? teacher.trim() : null,
                            type: type ? type.trim() : null,
                            groupe: groupe ? groupe.trim() : null,
                            code: code,
                            classNames: (year ? year.trim() : "") + (type ? type.trim() : "") + (groupe ? groupe.trim() : "") + (regex_summary.exec(event.summary.value) ? regex_summary.exec(event.summary.value)[0] : ""),
                            raw: event
                        }
                    } catch (e) {
                        console.log("u", e);
                        console.log("!!", event);
                    }
                })
                res.json(data_to_send);
                cache.put(code, data_to_send, 5 * 60 * 1000);//5minutes
            })
        } else {
            res.json(data_cached);
        }
}

module.exports = {
    downloader
}