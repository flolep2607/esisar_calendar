# Recuperer les codes de classe
lancer generator.py tout les semestres

`export EDT_PASSWORD=`
`export EDT_USER=`