const express = require('express');
const app = express();
const fs = require("fs");
const api = express.Router();
const apicache = require("apicache");   
const { downloader } = require("./downloader.js");
let cache = apicache.middleware
app.get('/', (req, res) => {
    res.sendFile("index.html", { root: __dirname });
});
api.get("/ics/:code",cache(5*60*1000), (req, res) => { // cache 5 minutes
    downloaderics(req.params.code,res);
})
api.get("/json/:code", (req, res) => { // cache 5 minutes
    downloader(req.params.code,res);
})
api.get("/json", (req, res) => { // cache 5 minutes
    downloader(req.params.code,res);
})
api.get("/classes", (_, res) => { // cache 5 minutes
    fs.readFile("./classes.json", "utf8", (err, data) => {
        if (err) throw err;
        res.json(JSON.parse(data));
    });
})

app.use('/api', api);
app.listen(process.env.PORT || 8080, () => {
    console.log(`http://localhost:${process.env.PORT || 8080}`)
});
